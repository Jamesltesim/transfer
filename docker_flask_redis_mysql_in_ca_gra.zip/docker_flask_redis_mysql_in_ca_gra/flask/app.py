# coding:utf-8

from flask import Flask
from redis import Redis
from flask_sqlalchemy import SQLAlchemy
import pymysql

app = Flask(__name__)
redis = Redis(host='redis', port=6379)


#配置flask配置对象中键：SQLALCHEMY_DATABASE_URI

app.config['SQLALCHEMY_DATABASE_URI'] = "mysql+pymysql://root:12345678@192.168.56.102:3306/my_db?charset=utf8"

#配置flask配置对象中键：SQLALCHEMY_COMMIT_TEARDOWN,设置为True,应用会自动在每次请求结束后提交数据库中变动

app.config['SQLALCHEMY_COMMIT_TEARDOWN'] = True
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True

#获取SQLAlchemy实例对象，接下来就可以使用对象调用数据

db = SQLAlchemy(app)



#创建模型对象
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)

def __repr__(self):
    return '<User %r>' % self.username

# 1.创建表
db.create_all()

# 2.增加记录

user = User.query.filter_by(username='admin').first()#条件查询

@app.route('/')
def hello():
    try:
        redis.incr('hits')
    except RedisError:
        visits = "<i>cannot connect to Redis, counter disabled</i>"

    print(user.email)
    return 'Hello World! I have been seen'

if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)
